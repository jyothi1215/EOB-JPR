﻿using EmployeeOnBoardingProject.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace EmployeeOnBoardingProject.Repositories
{
    interface IEmp_PersonalDetails
    {
        int InsertEmployeeDetails(EmpDetails Ed);
        DataSet GetAllEmployeeDetails(EmpDetails Ed);
        int UpdatePersonalDetails(EmpDetails Ed);
        int DeleteEmpDetails(EmpDetails Ed);
    }
}

    
