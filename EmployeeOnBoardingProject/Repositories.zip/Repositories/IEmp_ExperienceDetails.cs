﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeOnBoardingProject.Repositories
{
    public class IEmp_ExperienceDetails
    {
    }
}