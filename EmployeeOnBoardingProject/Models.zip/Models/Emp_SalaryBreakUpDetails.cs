﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeOnBoardingProject.Models
{
    public class Emp_SalaryBreakUpDetails
    {
        public int SBDID { get; set; }
        public int EmployeeID { get; set; }
        public string ParticularName { get; set; }
        public string ParticularAmount { get; set; }

    }
}