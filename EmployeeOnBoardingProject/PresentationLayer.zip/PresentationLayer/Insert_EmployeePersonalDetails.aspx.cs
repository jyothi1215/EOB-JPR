﻿using EmployeeOnBoardingProject.BusinessAccessLayer;
using EmployeeOnBoardingProject.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace EmployeeOnBoardingProject.PresentationLayer
{
    public partial class Insert_EmployeePersonalDetails : System.Web.UI.Page
    {
      
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                GetEmployeeDetails();
            }
        }

        private void GetEmployeeDetails()
        {

            EmpDetails Ed = new EmpDetails();
            Emp_PersonalDetailsBAL bal = new Emp_PersonalDetailsBAL();
            DataSet dSet = bal.GetAllEmployeeDetails(Ed);

            dSet = bal.GetAllEmployeeDetails(Ed);

            GridView1.DataSource = dSet;
            GridView1.DataBind();



        }
    
  
        protected void Button1_Click(object sender, EventArgs e)
        {

            EmpDetails Ed = new EmpDetails();
            Emp_PersonalDetailsBAL bal = new Emp_PersonalDetailsBAL();
            try
            {
                //Ed.EmployeeID = Convert.ToInt32(TextBox1.Text.ToString());
                Ed.EmployeeFirstName = TextBox2.Text;
                Ed.EmployeeMiddleName = TextBox3.Text;
                Ed.EmployeeSurName = TextBox4.Text;
                Ed.BloodGroup = DropDownList1.SelectedItem.Value;
                Ed.DateOfBirth = DateTime.Parse(TextBox5.Text);
                Ed.PhoneNo = TextBox6.Text;
                Ed.AlternatePhoneNo = TextBox7.Text;
                Ed.MailID = TextBox8.Text;
                Ed.MaritalStatus = DropDownList2.SelectedItem.Value;
                Ed.Gender = Rdb_Gender.SelectedValue;
                
                Ed.PermanentCountryID = Convert.ToInt32(DropDownList3.SelectedItem.Value);
                Ed.PermanentStateID = Convert.ToInt32(DropDownList4.SelectedItem.Value);
                Ed.PermanentCityID = Convert.ToInt32(DropDownList5.SelectedItem.Value);
                Ed.PermanentColonyID = Convert.ToInt32(DropDownList6.SelectedItem.Value);
                Ed.PermanentHouseNo = TextBox9.Text;
                Ed.TemporaryCountryID = Convert.ToInt32(DropDownList7.SelectedItem.Value);
                Ed.TemporaryStateID = Convert.ToInt32(DropDownList8.SelectedItem.Value);
                Ed.TemporaryCityID = Convert.ToInt32(DropDownList9.SelectedItem.Value);
                Ed.TemporaryColonyID = Convert.ToInt32(DropDownList10.SelectedItem.Value);
                Ed.TemporaryHouseNo = TextBox10.Text;

                int Counter = bal.InsertEmployeeDetails(Ed);
                GetEmployeeDetails();
                Label22.Text = "<h2>Employee's Personal Details added successfully..</h2>";

            }
            catch (Exception ex)
            {
                Label22.Text = ex.Message;

            }







        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gvr = GridView1.SelectedRow;
            TextBox1.Text = gvr.Cells[1].Text;
            TextBox2.Text = gvr.Cells[2].Text;
            TextBox3.Text = gvr.Cells[3].Text;
            TextBox4.Text = gvr.Cells[4].Text;
            DropDownList1.SelectedItem.Value= gvr.Cells[5].Text;
            TextBox5.Text = gvr.Cells[6].Text;
            TextBox6.Text = gvr.Cells[7].Text;
            TextBox7.Text= gvr.Cells[8].Text;
            TextBox8.Text= gvr.Cells[9].Text;
            DropDownList2.SelectedItem.Value = gvr.Cells[10].Text;
            Rdb_Gender.SelectedValue = gvr.Cells[11].Text;
            DropDownList3.SelectedItem.Value = gvr.Cells[12].Text;
            DropDownList4.SelectedItem.Value = gvr.Cells[13].Text;
            DropDownList5.SelectedItem.Value = gvr.Cells[14].Text;
            DropDownList6.SelectedItem.Value = gvr.Cells[15].Text;
            TextBox9.Text = gvr.Cells[16].Text;
            DropDownList7.SelectedItem.Value = gvr.Cells[17].Text;
            DropDownList8.SelectedItem.Value = gvr.Cells[18].Text;
            DropDownList9.SelectedItem.Value = gvr.Cells[19].Text;
            DropDownList10.SelectedItem.Value = gvr.Cells[20].Text;
            TextBox10.Text = gvr.Cells[21].Text;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            EmpDetails Ed = new EmpDetails();
            Emp_PersonalDetailsBAL bal = new Emp_PersonalDetailsBAL();
            try
            {
                Ed.EmployeeID = Convert.ToInt32(TextBox1.Text);
                Ed.EmployeeFirstName = TextBox2.Text;
                Ed.EmployeeMiddleName = TextBox3.Text;
                Ed.EmployeeSurName = TextBox4.Text;
                Ed.BloodGroup = DropDownList1.SelectedItem.Value;
                Ed.DateOfBirth = DateTime.Parse(TextBox5.Text);
                Ed.PhoneNo = TextBox6.Text;
                Ed.AlternatePhoneNo = TextBox7.Text;
                Ed.MailID = TextBox8.Text;
                Ed.MaritalStatus = DropDownList2.SelectedItem.Value;
                Ed.Gender = Rdb_Gender.SelectedItem.Value;
                Ed.PermanentCountryID = Convert.ToInt32(DropDownList3.SelectedItem.Value);
                Ed.PermanentStateID = Convert.ToInt32(DropDownList4.SelectedItem.Value);
                Ed.PermanentCityID = Convert.ToInt32(DropDownList5.SelectedItem.Value);
                Ed.PermanentColonyID = Convert.ToInt32(DropDownList6.SelectedItem.Value);
                Ed.PermanentHouseNo = TextBox9.Text;
                Ed.TemporaryCountryID = Convert.ToInt32(DropDownList7.SelectedItem.Value);
                Ed.TemporaryStateID = Convert.ToInt32(DropDownList8.SelectedItem.Value);
                Ed.TemporaryCityID = Convert.ToInt32(DropDownList9.SelectedItem.Value);
                Ed.TemporaryColonyID = Convert.ToInt32(DropDownList10.SelectedItem.Value);
                Ed.TemporaryHouseNo = TextBox10.Text;

                int Counter = bal.UpdatePersonalDetails(Ed);
                GetEmployeeDetails();
                Label22.Text = "<h2>Employee's Personal Details Updated successfully..</h2>";

            }
            catch (Exception ex)
            {
                Label22.Text = ex.Message;

            }

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            EmpDetails Ed = new EmpDetails();
            Emp_PersonalDetailsBAL bal = new Emp_PersonalDetailsBAL();
            try
            {
                Ed.EmployeeID = Convert.ToInt32(TextBox1.Text.ToString());
                int Counter = bal.DeleteEmpDetails(Ed);
                
                Label22.Text = "<h2>Employee's Personal Details Deleted successfully..</h2>";


            }
              

            catch (Exception ex)
            {
                Label22.Text = ex.Message;

            }

        }

       
    }
}
















