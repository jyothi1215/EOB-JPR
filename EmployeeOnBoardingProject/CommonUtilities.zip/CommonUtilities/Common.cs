﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace EmployeeOnBoardingProject.CommonUtilities
{
    public class Common
    {
        public static string GetConnectionString()
        {
            string str = ConfigurationManager.ConnectionStrings["MyCS"].ConnectionString;
            return (str);
        }

        #region List Of Stored Procedures
        public static string Usp_insertPersonalDetails = "Usp_insertPersonalDetails";
        public static string Usp_GetAllEmployeeDetails = "Usp_GetAllEmployeeDetails";
        public static string Usp_UpdatePersonalDetails = "Usp_UpdatePersonalDetails";
        public static string Usp_DeletePersonalDetails = "Usp_DeletePersonalDetails";

        #endregion
    }
}
